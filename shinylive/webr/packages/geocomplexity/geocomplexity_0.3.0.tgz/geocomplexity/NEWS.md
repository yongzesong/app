# geocomplexity 0.3.0

* Correct maintainer surname spelling from `Lv` to `Lyu` for pinyin compliance (#3).

# geocomplexity 0.2.1

* Include a citation for the `geocomplexity` package (#2).

# geocomplexity 0.2.0

* Transfer `moran_test` function to `sdsfun` package (#1).

* Removing `tidyverse` from the dependencies suggested by package.

# geocomplexity 0.1.0

* Support the computation of geographical complexity by leveraging spatial dependence and geographical configuration similarity for both spatial vector and spatial raster data.

* Develop spatial weight matrices by leveraging geographical complexity.

* Implement geographical complexity-geographically weighted regression.
